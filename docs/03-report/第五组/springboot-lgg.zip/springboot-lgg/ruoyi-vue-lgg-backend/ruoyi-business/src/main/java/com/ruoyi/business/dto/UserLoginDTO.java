package com.ruoyi.business.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * C端用户登录
 */
@Data
public class UserLoginDTO implements Serializable {

    private String code;
    private String name;
    private String avatar;
    private String sex;

}
