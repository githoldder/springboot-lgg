package com.ruoyi.business.controller.admin;

import com.ruoyi.business.dto.OrdersCancelDTO;
import com.ruoyi.business.dto.OrdersAssignRiderDTO;
import com.ruoyi.business.dto.OrdersConfirmDTO;
import com.ruoyi.business.dto.OrdersPageQueryDTO;
import com.ruoyi.business.dto.OrdersRejectionDTO;
import com.ruoyi.business.result.PageResult;
import com.ruoyi.business.result.Result;
import com.ruoyi.business.service.OrderService;
import com.ruoyi.business.vo.OrderStatisticsVO;
import com.ruoyi.business.vo.OrderVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;

/**
 * 订单管理
 */
@RestController("adminOrderController")
@RequestMapping("/admin/order")
@Slf4j
@Api(tags = "订单管理接口")
public class OrderController {

    @Autowired
    private OrderService orderService;

    /**
     * 订单搜索
     *
     * @param ordersPageQueryDTO
     * @return
     */
    @GetMapping("/conditionSearch")
    @ApiOperation("订单搜索")
    public Result<PageResult> conditionSearch(OrdersPageQueryDTO ordersPageQueryDTO) {
        PageResult pageResult = orderService.conditionSearch(ordersPageQueryDTO);
        return Result.success(pageResult);
    }

    /**
     * 各个状态的订单数量统计
     *
     * @return
     */
    @GetMapping("/statistics")
    @ApiOperation("各个状态的订单数量统计")
    public Result<OrderStatisticsVO> statistics() {
        OrderStatisticsVO orderStatisticsVO = orderService.statistics();
        return Result.success(orderStatisticsVO);
    }

    /**
     * 订单详情
     *
     * @param id
     * @return
     */
    @GetMapping("/details/{id}")
    @ApiOperation("查询订单详情")
    public Result<OrderVO> details(@PathVariable("id") Long id) {
        OrderVO orderVO = orderService.details(id);
        return Result.success(orderVO);
    }

    /**
     * 接单
     *
     * @return
     */
    @PutMapping("/confirm")
    @ApiOperation("接单")
    public Result confirm(@RequestBody OrdersConfirmDTO ordersConfirmDTO) {
        orderService.confirm(ordersConfirmDTO);
        return Result.success();
    }

    /**
     * 拒单
     *
     * @return
     */
    @PutMapping("/rejection")
    @ApiOperation("拒单")
    public Result rejection(@RequestBody OrdersRejectionDTO ordersRejectionDTO) throws Exception {
        orderService.rejection(ordersRejectionDTO);
        return Result.success();
    }

    /**
     * 取消订单
     *
     * @return
     */
    @PutMapping("/cancel")
    @ApiOperation("取消订单")
    public Result cancel(@RequestBody OrdersCancelDTO ordersCancelDTO) throws Exception {
        orderService.cancel(ordersCancelDTO);
        return Result.success();
    }

    /**
     * 派送订单
     *
     * @return
     */
    @PutMapping("/delivery/{id}")
    @ApiOperation("派送订单")
    public Result delivery(@PathVariable("id") Long id) {
        orderService.delivery(id);
        return Result.success();
    }

    /**
     * 指派骑手
     *
     * @return
     */
    @PutMapping("/assignRider")
    @ApiOperation("指派骑手")
    public Result assignRider(@RequestBody OrdersAssignRiderDTO ordersAssignRiderDTO) {
        orderService.assignRider(ordersAssignRiderDTO);
        return Result.success();
    }

    /**
     * 完成订单
     *
     * @return
     */
    @PutMapping("/complete/{id}")
    @ApiOperation("完成订单")
    public Result complete(@PathVariable("id") Long id) {
        orderService.complete(id);
        return Result.success();
    }

    /**
     * 订单小票打印页
     *
     * @return
     */
    @GetMapping(value = "/print/{id}", produces = MediaType.TEXT_HTML_VALUE)
    @ApiOperation("订单小票打印页")
    public String print(@PathVariable("id") Long id) {
        return orderService.printReceipt(id);
    }

    /**
     * 导出订单记录
     */
    @PostMapping("/export")
    @ApiOperation("导出订单记录")
    public void export(HttpServletResponse response, OrdersPageQueryDTO ordersPageQueryDTO) {
        orderService.exportOrders(response, ordersPageQueryDTO);
    }
}
