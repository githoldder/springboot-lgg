package com.ruoyi.business.service;

import com.ruoyi.business.dto.*;
import com.ruoyi.business.result.PageResult;
import com.ruoyi.business.vo.OrderPaymentVO;
import com.ruoyi.business.vo.OrderStatisticsVO;
import com.ruoyi.business.vo.OrderSubmitVO;
import com.ruoyi.business.vo.OrderVO;

import jakarta.servlet.http.HttpServletResponse;

public interface OrderService {
    /**
     * 用户下单
     * @param ordersSubmitDTO
     * @return
     */
    OrderSubmitVO submitOrder(OrdersSubmitDTO ordersSubmitDTO);

    /**
     * 订单支付
     * @param ordersPaymentDTO
     * @return
     */
    OrderPaymentVO payment(OrdersPaymentDTO ordersPaymentDTO) throws Exception;

    /**
     * 支付成功，修改订单状态
     * @param outTradeNo
     */
    void paySuccess(String outTradeNo);

    /**
     * 用户端确认支付完成，模拟微信支付回调后的主动查询确认
     * @param orderNumber
     */
    OrderVO confirmPayment(String orderNumber);

    /**
     * 用户端订单分页查询
     * @param page
     * @param pageSize
     * @param status
     * @return
     */
    PageResult pageQuery4User(int page, int pageSize, Integer status);

    /**
     * 查询订单详情
     * @param id
     * @return
     */
    OrderVO details(Long id);

    /**
     * 用户取消订单
     * @param id
     */
    void userCancelById(Long id) throws Exception;

    /**
     * 再来一单
     * @param id
     */
    void repetition(Long id);

    /**
     * 条件搜索订单
     * @param ordersPageQueryDTO
     * @return
     */
    PageResult conditionSearch(OrdersPageQueryDTO ordersPageQueryDTO);

    /**
     * 各个状态的订单数量统计
     * @return
     */
    OrderStatisticsVO statistics();

    /**
     * 接单
     *
     * @param ordersConfirmDTO
     */
    void confirm(OrdersConfirmDTO ordersConfirmDTO);

    /**
     * 拒单
     *
     * @param ordersRejectionDTO
     */
    void rejection(OrdersRejectionDTO ordersRejectionDTO) throws Exception;

    /**
     * 商家取消订单
     *
     * @param ordersCancelDTO
     */
    void cancel(OrdersCancelDTO ordersCancelDTO) throws Exception;

    /**
     * 派送订单
     *
     * @param id
     */
    void delivery(Long id);

    /**
     * 指派骑手
     * @param ordersAssignRiderDTO
     */
    void assignRider(OrdersAssignRiderDTO ordersAssignRiderDTO);

    /**
     * 完成订单
     *
     * @param id
     */
    void complete(Long id);

    /**
     * 客户催单
     * @param id
     */
    void reminder(Long id);

    /**
     * 订单小票HTML
     * @param id
     * @return
     */
    String printReceipt(Long id);

    /**
     * 导出订单记录
     * @param response
     * @param ordersPageQueryDTO
     */
    void exportOrders(HttpServletResponse response, OrdersPageQueryDTO ordersPageQueryDTO);
}
